export const isLoggedIn:any=[{
    user:{
        name:"amirtha"
    }
}]