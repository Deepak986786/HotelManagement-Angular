export const dummybookings:any=[
    {"id":1,"userId":"amirtha@gmail.com","numberOfDaysStay":2,"price":1000,"bookingDate":"2022-11-14T00:00:00"}
];

 export const dummybookingsmock:any=[
     {"id":1,"userId":"amirtha@gmail.com","numberOfDaysStay":7,"price":1000,"bookingDate":"2022-11-14T00:00:00"}
 ];

 export const loggedInDetails:any=[{
   user:{
    email:"amirtha@gmail.com",
    password:"1234",
   },
    token:"asdfghjkl"
 }
 ]

 export const login:any={
     
     email:"amirtha@gmail.com",
     password:"12345"
 }
 export const dummyUser=  {
    name:"amirtha",
    profilePic:"https://www.bing.com/th?id=OIP.4lvhDGxwRYkur9Z5jeia7AHaFg&w=150&h=112&c=8&rs=1&qlt=90&o=6&dpr=1.5&pid=3.1&rm=2",
    phoneNumber:"1234567890",
    aadhaarId:"123456789012",
    email:"amirtha@gmail.com",
    password:"1234"
    } 

 export const loggedIn={
    user:{
        name:"amirtha",
        profilePic:"https://www.bing.com/th?id=OIP.4lvhDGxwRYkur9Z5jeia7AHaFg&w=150&h=112&c=8&rs=1&qlt=90&o=6&dpr=1.5&pid=3.1&rm=2",
        phoneNumber:"1234567890",
        aadhaarId:"123456789012",
        email:"amirtha@gmail.com",
        password:"1234"
        }   ,
        token:"qwertyui" 
 }

